Installation
------------

1. Open a terminal from this folder (Right click -> Open terminal).
2. Type this and press enter:

sudo ./install.sh install

3. To import words, type this and press enter:

./import.sh