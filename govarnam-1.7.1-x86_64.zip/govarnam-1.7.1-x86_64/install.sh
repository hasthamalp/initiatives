#!/bin/bash

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

ARG1=${1:-install}

if [ "$ARG1" == "install" ]; then
  sudo cp "$SCRIPT_DIR/varnamcli" "/usr/local/bin/varnamcli"
  
  sudo mkdir -p "/usr/local/lib/pkgconfig"
  sudo cp "$SCRIPT_DIR/libgovarnam.so" "/usr/local/lib/libgovarnam.so.1.7.1"
  sudo ln -s "/usr/local/lib/libgovarnam.so.1.7.1" "/usr/local/lib/libgovarnam.so"
  sudo cp "$SCRIPT_DIR/govarnam.pc" "/usr/local/lib/pkgconfig/"

  sudo mkdir -p "/usr/local/include/libgovarnam"
  sudo cp "$SCRIPT_DIR/"*.h "/usr/local/include/libgovarnam/"
  sudo ldconfig

  sudo mkdir -p "/usr/local/share/varnam/schemes"

  msg="Installation finished"
  echo "$msg"

  notify-send "$msg" &> /dev/null || true
elif [ "$ARG1" == "uninstall" ]; then
  sudo rm "/usr/local/bin/varnamcli" "/usr/local/lib/libgovarnam.so.1.7.1" "/usr/local/lib/libgovarnam.so" "/usr/local/lib/pkgconfig/govarnam.pc"
  sudo rm "/usr/local/include/libgovarnam/"*
  sudo rmdir "/usr/local/include/libgovarnam"
  sudo rm "/usr/local/share/varnam/schemes/"*
  sudo rmdir "/usr/local/share/varnam/schemes/"

  msg="Uninstallation finished"
  echo $msg
else
  echo "Unknown argument"
fi
