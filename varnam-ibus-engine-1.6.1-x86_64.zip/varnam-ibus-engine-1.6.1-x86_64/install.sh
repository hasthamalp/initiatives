#!/bin/bash

# TODO change govarnam to varnam

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" &> /dev/null && pwd )"

ARG1=${1:-install}

if [ "$ARG1" == "install" ]; then
  if [ -f "/usr/local/bin/varnam-ibus-engine" ]; then
    sudo rm "/usr/local/bin/varnam-ibus-engine"
  fi
  sudo cp "$SCRIPT_DIR/varnam-ibus-engine" "/usr/local/bin/varnam-ibus-engine"

  sudo mkdir -p "/usr/local/share/varnam/ibus/icons"
  sudo cp "$SCRIPT_DIR/icons/"*.png "/usr/local/share/varnam/ibus/icons/"
  sudo cp "$SCRIPT_DIR/component/"*.xml "/usr/share/ibus/component"

  msg="Installation finished. Restart ibus to add new input method."
  echo "$msg"
  notify-send "$msg" &> /dev/null || true
elif [ "$ARG1" == "uninstall" ]; then
  sudo rm "/usr/local/bin/varnam-ibus-engine"
  for XML in $(find "$SCRIPT_DIR/component/"*.xml -printf "%f\n"); do
    sudo rm "/usr/share/ibus/component/$XML"
  done
  for ICON in $(find "$SCRIPT_DIR/icons/"*.png -printf "%f\n"); do
    sudo rm "/usr/local/share/varnam/ibus/icons/$ICON"
  done
  sudo rmdir "/usr/local/share/varnam/ibus/icons"
  sudo rmdir "/usr/local/share/varnam/ibus"
  sudo rmdir "/usr/local/share/varnam"

  echo "Uninstallation finished"
fi
